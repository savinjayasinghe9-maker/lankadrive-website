CREATE TABLE IF NOT EXISTS cars (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  make TEXT NOT NULL,
  model TEXT NOT NULL,
  year INTEGER NOT NULL,
  price_lkr INTEGER NOT NULL,
  mileage_km INTEGER DEFAULT 0,
  transmission TEXT DEFAULT 'Automatic',
  fuel TEXT DEFAULT 'Petrol',
  body_type TEXT DEFAULT 'Sedan',
  location TEXT DEFAULT 'Colombo',
  description TEXT DEFAULT '',
  image_url TEXT DEFAULT '',
  featured INTEGER DEFAULT 0,
  status TEXT DEFAULT 'available',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS enquiries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  car_id INTEGER,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT DEFAULT '',
  message TEXT DEFAULT '',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(car_id) REFERENCES cars(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_cars_status ON cars(status);
CREATE INDEX IF NOT EXISTS idx_enquiries_created ON enquiries(created_at);
