# LankaDrive — Sri Lankan vehicle marketplace

A bilingual (English / සිංහල) car-listing website for Cloudflare Pages, Workers Functions, D1 and R2.
Includes animated responsive storefront, search/filtering, enquiry form, password-protected admin,
car CRUD, enquiry inbox, and photo upload to R2.

## 1. What you need
- A Cloudflare account
- Node.js 20+ and npm
- Wrangler CLI (`npm install -g wrangler`)
- A domain is optional

## 2. Create the D1 database
Open a terminal in this project folder:

```bash
npm install
npx wrangler login
npx wrangler d1 create lankadrive-db
```

Cloudflare prints a `database_id`. Copy it into `wrangler.toml` where it says `REPLACE_WITH_YOUR_D1_DATABASE_ID`.

Create the tables:

```bash
npx wrangler d1 execute lankadrive-db --remote --file=./schema.sql
```

For local development, use `--local` instead of `--remote`.\n\nOptional: add clearly marked sample listings with `npx wrangler d1 execute lankadrive-db --remote --file=./seed-demo.sql`. Delete these demo rows or replace their details before launch.

## 3. Create an R2 bucket for car photos
```bash
npx wrangler r2 bucket create lankadrive-photos
```
The bucket name is already in `wrangler.toml`. To display uploaded photos publicly, connect the bucket to an R2 custom domain in Cloudflare:
1. Cloudflare Dashboard → R2 Object Storage → `lankadrive-photos`
2. Settings → Public access / Custom Domains → Connect domain.
3. Copy the public base URL (for example `https://images.yourdomain.lk`) into `R2_PUBLIC_BASE_URL` in `wrangler.toml` (no trailing slash).
Do not expose the bucket with public access unless you are comfortable with listing photos being public.

## 4. Set admin credentials (do not put passwords in source files)
```bash
npx wrangler secret put ADMIN_PASSWORD
npx wrangler secret put SESSION_SECRET
```
Enter a strong, unique admin password when prompted. For SESSION_SECRET, enter a long random secret (at least 32 characters). Keep both private.

## 5. Run locally
```bash
npm run dev
```
Wrangler starts a local Pages-compatible preview. Open the local URL it prints.
Local secrets can be placed in `.dev.vars` (never commit this file):
```ini
ADMIN_PASSWORD=change-this-local-password
SESSION_SECRET=use-a-long-random-local-secret-value
R2_PUBLIC_BASE_URL=http://localhost:8788
```
D1 and R2 local bindings are configured in `wrangler.toml`.

## 6. Deploy to Cloudflare Pages
Recommended Git deployment:
1. Create a GitHub repository and upload this project (do not upload `.dev.vars`).
2. Cloudflare Dashboard → Workers & Pages → Create → Pages → Connect to Git.
3. Select the repository.
4. Build command: `npm run build`
5. Build output directory: `public`
6. Deploy.

Then open the Pages project → Settings → Functions → Bindings:
- D1 database binding: variable name `DB`, select `lankadrive-db`.
- R2 bucket binding: variable name `PHOTOS`, select `lankadrive-photos`.
Add environment variables / secrets:
- `ADMIN_PASSWORD` (secret)
- `SESSION_SECRET` (secret)
- `R2_PUBLIC_BASE_URL` (plain variable, your R2 custom-domain URL)

If you use the Wrangler configuration included here, it defines the bindings for Wrangler deployments. For dashboard Git deployments, verify the bindings in Pages settings too.

CLI deployment alternative:
```bash
npm run build
npx wrangler pages deploy public --project-name=lankadrive
```
Before using CLI deployment, create the Pages project if Wrangler asks, and ensure the D1/R2 bindings and secrets are set for that Pages project.

## 7. First use
- Open the deployed site.
- Click **Admin** in the header.
- Sign in with the password you set as `ADMIN_PASSWORD`.
- Add a car, upload a photo, and publish it.
- Open a car and send a test enquiry. It appears in the admin Enquiries tab.

## Notes / safety
- Prices are entered in Sri Lankan rupees (LKR).
- This starter uses one shared admin password. Only share it with trusted site administrators.
- Use HTTPS, a strong password, and a long random `SESSION_SECRET`.
- R2 photo URLs are public if you configure a public custom domain; do not upload private documents.
- Add your own privacy policy, business contact details, terms, and legal checks before accepting real customer data.
- The included demo cars are examples. Remove or edit them before launch.
