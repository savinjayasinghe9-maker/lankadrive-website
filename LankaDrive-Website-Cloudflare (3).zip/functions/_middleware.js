async function sign(value, secret) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), {name:"HMAC",hash:"SHA-256"}, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value));
  return btoa(String.fromCharCode(...new Uint8Array(sig))).replaceAll("+","-").replaceAll("/","_").replaceAll("=","");
}
export async function onRequest(context) {
  const {request, env} = context;
  const url = new URL(request.url);
  if (!url.pathname.startsWith("/api/") || url.pathname.startsWith("/api/auth/") || request.method === "OPTIONS") return context.next();
  const open = (request.method === "POST" && url.pathname === "/api/enquiries") ||
    (request.method === "GET" && url.pathname === "/api/cars");
  if (open) return context.next();
  const cookie = request.headers.get("Cookie") || "";
  const token = cookie.split(";").map(x=>x.trim()).find(x=>x.startsWith("ld_session="))?.slice(11);
  if (!token || !env.SESSION_SECRET) return Response.json({error:"Admin login required"}, {status:401});
  const [payload, signature] = token.split(".");
  if (!payload || !signature || await sign(payload, env.SESSION_SECRET) !== signature) return Response.json({error:"Invalid session"}, {status:401});
  try {
    const data = JSON.parse(atob(payload.replaceAll("-","+").replaceAll("_","/")));
    if (data.exp < Date.now()) throw new Error("expired");
  } catch { return Response.json({error:"Session expired"}, {status:401}); }
  return context.next();
}
