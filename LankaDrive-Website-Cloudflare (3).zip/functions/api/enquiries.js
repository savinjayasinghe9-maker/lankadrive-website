export async function onRequestPost({request,env}) {
 const b=await request.json();
 if(!b.customer_name||!b.phone) return Response.json({error:"Name and phone are required"}, {status:400});
 await env.DB.prepare("INSERT INTO enquiries (car_id,customer_name,phone,email,message) VALUES (?,?,?,?,?)").bind(b.car_id||null,b.customer_name,b.phone,b.email||"",b.message||"").run();
 return Response.json({ok:true});
}
export async function onRequestGet({env}) {
 const {results=[]}=await env.DB.prepare("SELECT e.*, c.title AS car_title FROM enquiries e LEFT JOIN cars c ON c.id=e.car_id ORDER BY e.created_at DESC").all();
 return Response.json(results);
}
