async function sign(value, secret) {
 const key=await crypto.subtle.importKey("raw",new TextEncoder().encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign"]);
 const sig=await crypto.subtle.sign("HMAC",key,new TextEncoder().encode(value));
 return btoa(String.fromCharCode(...new Uint8Array(sig))).replaceAll("+","-").replaceAll("/","_").replaceAll("=","");
}
export async function onRequestPost({request,env}) {
 const body=await request.json().catch(()=>({}));
 if(!env.ADMIN_PASSWORD || !env.SESSION_SECRET) return Response.json({error:"Admin secrets are not configured"}, {status:500});
 if(typeof body.password!=="string" || body.password!==env.ADMIN_PASSWORD) return Response.json({error:"Incorrect password"}, {status:401});
 const payload=btoa(JSON.stringify({exp:Date.now()+8*60*60*1000})).replaceAll("+","-").replaceAll("/","_").replaceAll("=","");
 const token=payload+"."+await sign(payload,env.SESSION_SECRET);
 return new Response(JSON.stringify({ok:true}),{headers:{"Content-Type":"application/json","Set-Cookie":`ld_session=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=28800`}});
}
