export async function onRequestPost({request,env}) {
 const form=await request.formData(), file=form.get("file");
 if(!file || typeof file==="string") return Response.json({error:"Choose an image"}, {status:400});
 if(!file.type.startsWith("image/")) return Response.json({error:"Only image files are allowed"}, {status:400});
 if(file.size>6*1024*1024) return Response.json({error:"Image must be 6 MB or smaller"}, {status:400});
 const ext=(file.type.split("/")[1]||"jpg").replace("jpeg","jpg").replace(/[^a-z0-9]/g,"");
 const key=`cars/${crypto.randomUUID()}.${ext}`;
 await env.PHOTOS.put(key,file.stream(),{httpMetadata:{contentType:file.type,cacheControl:"public, max-age=31536000"}});
 const base=(env.R2_PUBLIC_BASE_URL||"").replace(/\/$/,"");
 if(!base || base.includes("YOUR-R2")) return Response.json({ok:true,key,url:"",warning:"Set R2_PUBLIC_BASE_URL to your R2 custom domain to display uploaded images."});
 return Response.json({ok:true,key,url:`${base}/${key}`});
}
