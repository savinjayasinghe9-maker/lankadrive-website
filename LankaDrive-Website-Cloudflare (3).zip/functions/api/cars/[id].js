export async function onRequestPut({request,env,params}) {
 const b=await request.json(), fields=["title","make","model","year","price_lkr","mileage_km","transmission","fuel","body_type","location","description","image_url","featured","status"];
 if(!b.title||!b.make||!b.model||!b.year||!b.price_lkr) return Response.json({error:"Required fields are missing"}, {status:400});
 await env.DB.prepare(`UPDATE cars SET ${fields.map(k=>k+" = ?").join(",")} WHERE id = ?`).bind(...fields.map(k=>b[k]??""),params.id).run();
 return Response.json({ok:true});
}
export async function onRequestDelete({env,params}) {
 await env.DB.prepare("DELETE FROM cars WHERE id = ?").bind(params.id).run();
 return Response.json({ok:true});
}
