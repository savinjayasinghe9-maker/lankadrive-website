export async function onRequestGet({request,env}) {
 const url=new URL(request.url), q=url.searchParams.get("q"), make=url.searchParams.get("make"), status=url.searchParams.get("status")||"available";
 let sql="SELECT * FROM cars WHERE status = ?"; const args=[status];
 if(q){sql+=" AND (title LIKE ? OR make LIKE ? OR model LIKE ? OR location LIKE ?)";args.push(...Array(4).fill(`%${q}%`));}
 if(make){sql+=" AND make = ?";args.push(make);}
 sql+=" ORDER BY featured DESC, created_at DESC";
 const {results=[]}=await env.DB.prepare(sql).bind(...args).all();
 return Response.json(results);
}
export async function onRequestPost({request,env}) {
 const b=await request.json();
 const fields=["title","make","model","year","price_lkr","mileage_km","transmission","fuel","body_type","location","description","image_url","featured","status"];
 if(!b.title||!b.make||!b.model||!b.year||!b.price_lkr) return Response.json({error:"Title, make, model, year and price are required"}, {status:400});
 const values=fields.map(k=>b[k]??(k==="status"?"available":k==="location"?"Colombo":k==="featured"?0:""));
 const stmt=await env.DB.prepare(`INSERT INTO cars (${fields.join(",")}) VALUES (${fields.map(()=>"?").join(",")})`).bind(...values).run();
 return Response.json({ok:true,id:stmt.meta.last_row_id});
}
